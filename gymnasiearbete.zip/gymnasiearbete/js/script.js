let currentDate = new Date(); // Current date object
let currentYear = currentDate.getFullYear();
let currentMonth = currentDate.getMonth(); // 0 is January, 11 is December

// Function to generate the calendar for the current month
function generateCalendar() {
    const calendarDiv = document.querySelector('.calendar');
    const monthYearSpan = document.getElementById('monthYear');

    // Update the month and year display
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    monthYearSpan.textContent = `${months[currentMonth]} ${currentYear}`;

    // First, determine how many days are in this month
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate(); // Get the last day of the month
    const firstDay = new Date(currentYear, currentMonth, 1).getDay(); // Get the first day of the month (0-6)

    // Clear any previous days in the calendar
    const days = calendarDiv.querySelectorAll('.day');
    days.forEach(day => day.remove());

    // Add empty divs for the days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
        const emptyDay = document.createElement('div');
        emptyDay.classList.add('day');
        calendarDiv.appendChild(emptyDay);
    }

    // Add the days of the month
    for (let day = 1; day <= daysInMonth; day++) {
        const dayDiv = document.createElement('div');
        dayDiv.classList.add('day');
        dayDiv.textContent = day;
        calendarDiv.appendChild(dayDiv);
    }
}

// Function to go to the next month
document.getElementById('nextMonth').addEventListener('click', function() {
    if (currentMonth === 11) { // If it's December, move to next year
        currentMonth = 0;
        currentYear++;
    } else {
        currentMonth++;
    }
    generateCalendar();
});

// Function to go to the previous month
document.getElementById('prevMonth').addEventListener('click', function() {
    if (currentMonth === 0) { // If it's January, move to previous year
        currentMonth = 11;
        currentYear--;
    } else {
        currentMonth--;
    }
    generateCalendar();
});

// Initialize the calendar on page load
generateCalendar();
